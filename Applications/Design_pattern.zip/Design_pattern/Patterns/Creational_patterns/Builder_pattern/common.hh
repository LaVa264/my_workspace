#include <string>
namespace larva
{
    using age = uint8_t;
    using name = std::string;
    using street_address = std::string;
    using post_code = std::string;
    using city = std::string;
    using company_name = std::string;
    using position = std::string;
    using annual_income = uint32_t;
}