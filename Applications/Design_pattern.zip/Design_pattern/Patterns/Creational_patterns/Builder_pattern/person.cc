#include "person.hh"
#include "person_builder.hh"

person_builder person::create()
{
    return person_builder();
}