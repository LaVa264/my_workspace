#include <iostream>

enum class color: uint8_t 
{
    red,
    blue,
    green,
    yellow
};

enum class size: uint8_t 
{
    small,
    medium,
    large
};

int main()
{

}